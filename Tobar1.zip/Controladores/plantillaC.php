<?php

class Plantilla{

	public function LlamarPlantilla(){

		include "Vistas/plantilla.php";

	}

}
   ?>

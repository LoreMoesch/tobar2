<?php
class ConexionBD{
	static public function cBD(){
        //$bd = new PDO("mysql:host=localhost;dbname=idukaye1_tobar", "idukaye1_joset", "Y-nKvw!b?nW3");
		//$bd = new PDO("mysql:host=localhost;dbname=idukaye1_tobar", "idukaye1_admint", "jesucristovive1308");
	    $bd = new PDO("mysql:host=localhost;dbname=idukaye1_tobar", "idukaye1_jose", "jesuscristovive_4420");
        //$bd = new PDO("mysql:host=localhost;dbname=idukaye1_tobar", "root", "");
	    $bd -> exec("set names utf8");
		return $bd;
	}
}

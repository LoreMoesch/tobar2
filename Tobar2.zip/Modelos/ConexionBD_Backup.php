<?php

class ConexionBD{

	public function cBD(){

		$bd = new PDO("mysql:host=localhost;dbname=idukaye1_tobar", "idukaye1_admint", "jesucristovive1308");

		$bd -> exec("set names utf8");

		return $bd;

	}

}

<?php
								
    $cambeditar = new MateriasC();

    $cambeditar -> CambiarediC();

?>

<?php
								
    $borrare = new MateriasC();

    $borrare -> BorrarEquipoC();

?>

<?php

if($_SESSION["rol"] != "Administrador"){
    
    if($_SESSION["rol"] != "Bedel"){
    
    	echo '<script>
    
    	window.locations = "inicio";
    
    	</script>';
    
    	return;
    
    }

}

//$exp = explode("/", $_GET["url"]);

//$llamado = $exp[2];

?>

<div class="container">
    
	<section class="container">
	
		<h2>Gestor de Exámenes</h2>
		
	</section>
	
	<section class="container">
	
		<div class="box">
	
			<div class="box-body">
	
				<?php
	
				$crearCarrera = new CarrerasC();
	
				$crearCarrera -> CrearCarreraC();
	
				?>
	
				

				<?php
	
				$columna = "id";
	
				$valor = 1;
	
				$resultado = AjustesC::VerAjustesC($columna, $valor);
	
				if($resultado["h_examenes"] == 0){
	
					echo '<button class="btn btn-success" type="submit" data-toggle="modal" data-target="#HE">Habilitar Inscripciones a Examenes</button>&nbsp;&nbsp;';
	
				}else{
	
					echo '<button class="btn btn-warning" type="submit" data-toggle="modal" data-target="#DE">Deshabilitar Inscripciones a Examenes</button>&nbsp;&nbsp;';
	
				}
	
				if($_SESSION["rol"] == "Administrador"){
				    
				    echo '<button class="btn btn-danger pull-right" type="submit" data-toggle="modal" data-target="#VaciarRegistrosExamenes">Vaciar Registros de Inscripciones a los Examenes</button>';
                }
                
                	
                ?>
                
        <br>
        <br>
	
				<table class="table table-bordered table-hover table-striped">
				    
					<thead>
					
						<tr>
					
							<th>Código</th>
					
							<th>Nombre</th>
					
							<th>Inscriptos</th>
							
							 <th>Marzo</th>
							 
						</tr>
					
					</thead>
					
					<tbody>

						<?php

						$carrera = CarrerasC::VerCarrerasC();
						

						foreach ($carrera as $key => $value) {
						    
						    //validar orientaciones
                            
                            if ($value["id"] == 6 || $value["id"] == 7 || $value["id"] == 8 || $value["id"] == 9 || $value["id"] == 12){
							    
							    echo '<tr>

									<td>'.$value["id"].'</td>
									
									<td>'.$value["nombre"].'</td>

									';
									
									$i=0;
									
									$ii=0;
									
									$exam = ExamenesC::VerInscExamentodosC();
									
									//esto es en insc_examen ($exam) 
									
									foreach ($exam as $key => $inscripexa) {
        						       
        						      $columna= "id";
        						      
        						      $valor=$inscripexa["id_alumno"];
        						      
        						      $usua=UsuariosC:: VerUsuariosC($columna, $valor);
        						      
                                	  $columna = "id";
	
				                      $valor = $inscripexa["id_examen"];        						      
        						      
        						      $exa= ExamenesC::VerExamenesC($columna, $valor);
        						         
        						      if ($value["id"] == 6 ){
        						          
       						               if ($exa["id_carrera"] == 6){
       						               
       						                        if ($inscripexa["llamado"]==1){

      						                          $i++;
                                         
       						                        }
                        					      if ($inscripexa["llamado"]==2){
        						      
        	      		            			      $ii++;
        						      
        						                  }

   						                    }        						        

        						      } else if ($value["id"] == 7 ){
        						          
           						          if ($exa["id_carrera"] == 7){
           						          
            					            if ($inscripexa["llamado"]==1){

                   						      $i++;
                                         
        						           }
        		    				      if ($inscripexa["llamado"]==2){
        						      
        			        			      $ii++;
        						      
        					    	      }

        						        }        						      

        						      } else if ($value["id"] == 8 ){
        						          
        						          if ($exa["id_carrera"] == 8){
        						          
        						            if ($inscripexa["llamado"]==1){

            						      $i++;
                                         
        						           }
             						      if ($inscripexa["llamado"]==2){
        						      
             						      $ii++;

             						      }
     
        						        }

        						      } else if ($value["id"] == 9 ){
        						          
        						          if ($exa["id_carrera"] == 9){
        						          
        						            if ($inscripexa["llamado"]==1){

                 						      $i++;
                                         
        						           }
              						      if ($inscripexa["llamado"]==2){
        						      
                						      $ii++;
        						      
        	     					      }

        						        } 
        						        
        						      } else if ($value["id"] == 12){

        						          if ($exa["id_carrera"] == 11 ){

                                            if($inscripexa["llamado"]==1) {
            						    
            						        $i++;

                                            }
              						      if ($inscripexa["llamado"]==2){
        						      
                						      $ii++;
        						      
        	     					      }

        						          }

        						      } 

        						      }

							   //primera columna
							   echo '

									<td>'.$ii.'</td>
									
                                    <td> 		

										

											<a href="Ver-Examenes/'.$value["id"].'/2">

												<button class="btn btn-success">Ver Exámenes</button>

											</a>
											';

                                    /// segunda columna

								///	echo '

								///	</td>

								///	<td>'.$ii.'</td>

                                ///    <td>

                            ///        <div class="btn-group">

							///		<a href="Ver-Examenes/'.$value["id"].'/2">

							///		<button class="btn btn-success">Ver Exámenes</button>

							///		</a>';

							
							///		 echo '</div>';

									 echo '</td>';

								echo '</tr>';
                            
						    
						    }
						
						}

						?>

					</tbody>

				</table>

			</div>

		</div>

	</section>

</div>

<div class="modal fade" id="HE">
	<div class="modal-dialog">
		<div class="modal-content">
			<form method="post">
				<div class="modal-body">
					<div class="box-body">
						<div class="form-group">
							<h2>¿Está seguro que desea Habilitar las Inscripciones a Examenes?</h2>
							<input type="hidden" name="h_examenes" value="1">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success">Confirmar</button>
					<button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
				</div>
				<?php
				$HE = new AjustesC();
				$HE -> HEC();
				?>
			</form>
		</div>
	</div>
</div>


<div class="modal fade" id="DE">
	<div class="modal-dialog">
		<div class="modal-content">
			<form method="post">
				<div class="modal-body">
					<div class="box-body">
						<div class="form-group">
							<h2>¿Está seguro que desea Deshabilitar las Inscripciones a Examenes?</h2>
							<input type="hidden" name="h_examenes" value="0">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success">Confirmar</button>
					<button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
				</div>

			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="VaciarRegistrosExamenes">
	<div class="modal-dialog">
		<div class="modal-content">
			<form method="post">
				<div class="modal-body">
					<div class="box-body">
						<div class="form-group">
							<h2>¿Está seguro que desea Eliminar todas las Inscripciones a Examenes?</h2>
							<input type="hidden" name="EE" value="EE">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success">Confirmar</button>
					<button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
				</div>
				<?php
				//$vaciare = new MateriasC();
				//$vaciare -> VaciarRegistrosExamenesC();
				?>
			</form>
		</div>
	</div>
</div>
<!-- Esto es un comentario -->

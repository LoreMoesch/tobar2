<div class="content-wrapper">
	
	<section class="content">
		
		<div class="box-body">
			
       <?php

	       $guardarAjustes = new ExamenesC();
	
	       $guardarAjustes -> ActualizarExamenesC();

        ?>
        
		</div>

	</section>

</div>



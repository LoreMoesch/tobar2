<?php
								
    //$borrare = new MateriasC();

    $borrarins = new ExamenesC();

    //$borrare -> BorrarEquipoC();

    $borrarins -> BorrarinscexaC();
    
?>

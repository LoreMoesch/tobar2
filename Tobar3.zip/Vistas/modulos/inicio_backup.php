<!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
     <h1>
      Bienvenido al Sistema de Gestion Educativa del ISFD Dra. Carolina Tobar Garcia
     </h1>

   </section>

   <!-- Main content -->
   <section class="content">

     <!-- Default box -->
     <div class="box">
      
     <!-- /.box -->

   </section>
   <!-- /.content -->
 </div>

<?php
$exp = explode("/", $_GET["url"]);
if($_SESSION["id_carrera"] != $exp[1]){
	echo '<script>
	window.location = "https://sistema.isfdcarolinatobargarcia.edu.ar/inicio";
	</script>';
	return;
}

$borroe = new ExamenesC();
$borroe -> BorrarInscEC();
?>
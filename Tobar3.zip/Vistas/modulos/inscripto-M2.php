<?php

								
                      $borraro = new MateriasC();

            $borraro -> BorrarInscMC2();
								
					?>
					
